SELECT userid
FROM users
WHERE users.email = 'cinebuff@movieinfo.com';
