SELECT movid, title
FROM movies
WHERE releasedate >= '20210101'
ORDER BY movid;
